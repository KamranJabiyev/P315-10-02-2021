﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Fiorella.DAL;
using Fiorella.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Fiorella.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;
        public HomeController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            HomeVM homeVM = new HomeVM
            {
                Sliders = _context.Sliders.ToList(),
                FlowerMainText = _context.FlowerMainText.FirstOrDefault(),
                Categories = _context.Categories.Where(c => c.IsDeleted == false).ToList(),
                Products = _context.Products.Where(p => p.IsDeleted == false).Include(p => p.Category).ToList(),
                Banners = _context.Banner.FirstOrDefault()
                
            };
            return View(homeVM);
        }
    }
}