﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Fiorella.DAL;
using Fiorella.Models;
using Microsoft.AspNetCore.Mvc;

namespace Fiorella.Controllers
{
    public class ProductController : Controller
    {
        private readonly AppDbContext _context;
        private int _productCount;
        public ProductController(AppDbContext context)
        {
            _context = context;
            _productCount= _context.Products.Where(p => p.IsDeleted == false).Count();
        }
        public IActionResult Index()
        {
            ViewBag.ProductCount = _productCount;
            return View(_context.Products.Where(p=>p.IsDeleted==false).Take(8).ToList());
        }

        public IActionResult LoadMore(int skip)
        {
            #region OldVersion
            //return Json(_context.Products.Skip(8).Take(8).ToList());
            #endregion
            if (skip >= _productCount)
            {
                return Json("get burdan");
            }
            List<Product> model = _context.Products.Where(p => p.IsDeleted == false).Skip(skip).Take(8).ToList();
            return PartialView("_ProductPartial", model);
        }
    }
}